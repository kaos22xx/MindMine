#!/usr/bin/env python3
"""
MindMine Submit - Claim mined blocks
Run this on a machine with web3.py installed
"""

import sys

# Fill these in!
NONCE = 0  # Replace with nonce from Pi
TIMESTAMP = 0  # Replace with timestamp from Pi
BLOCK_NUM = 0  # Replace with block number from Pi

# Or run with arguments:
# python3 submit.py <nonce> <timestamp> <block_num>

if len(sys.argv) >= 4:
    NONCE = int(sys.argv[1])
    TIMESTAMP = int(sys.argv[2])
    BLOCK_NUM = int(sys.argv[3])

print(f"Submitting nonce: {NONCE}")
print(f"Timestamp: {TIMESTAMP}")
print(f"Block: {BLOCK_NUM}")
print("\nYou need web3.py to sign and submit!")
print("Install: pip install web3 eth-account")
print("Then I'll create the full submit script")
