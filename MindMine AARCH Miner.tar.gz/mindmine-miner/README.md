# MindMine Miner

CPU miner for MindMine (MIND) token on Arbitrum.

## Requirements

- Raspberry Pi or any Linux system
- Python 3.7+

## Installation

```bash
# Install Python dependencies
pip install -r requirements.txt

# Or use virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## Usage

### 1. Configure

Edit `nonce-finder.py` and set your wallet address:

```python
MINER_ADDRESS = "0xYOUR_WALLET_ADDRESS"
```

### 2. Run the miner

```bash
python3 nonce-finder.py
```

The miner will:
- Connect to Arbitrum network
- Find valid nonces for SHA-256 proof-of-work
- Display found nonces

### 3. Submit (requires web3.py)

When a valid nonce is found, submit it using a machine with web3.py:

```bash
python3 submit.py <nonce> <timestamp> <block_number>
```

## Configuration

- `RPC_URL`: Arbitrum RPC endpoint
- `CONTRACT`: MindMine contract address
- `DIFFICULTY`: Mining difficulty (default: 100)

## Contract Info

- **Network:** Arbitrum One
- **Contract:** 0x1df0eab2B1774056fa8cbaEb127be6A3827b3BB5
- **Token:** MIND
- **Reward:** 100 MIND per block

## Algorithm

SHA-256 proof-of-work:
```
hash = SHA256(timestamp + blockNumber + minerAddress + nonce)
valid = hash < 2^(256 - difficulty)
```

## Files

- `nonce-finder.py` - Find valid nonces (works on Pi/ARM)
- `submit.py` - Submit nonce to blockchain (needs web3.py)
- `requirements.txt` - Python dependencies
