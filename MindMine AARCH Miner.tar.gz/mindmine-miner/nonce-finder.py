#!/usr/bin/env python3 CPU Miner - Nonce
"""
MindMine Finder (for ARM/Pi)
Finds valid nonces, outputs them for signing on another machine
"""

import hashlib
import sys
import time

# Configuration
RPC_URL = "https://arb1.arbitrum.io/rpc"
CONTRACT = "0x1df0eab2B1774056fa8cbaEb127be6A3827b3BB5"

DIFFICULTY = 100

# Your wallet address
MINER_ADDRESS = "0xYOUR_WALLET_ADDRESS_HERE"

def check_proof(nonce, timestamp, block_num, miner):
    """Check if nonce produces valid hash"""
    data = f"{timestamp}{block_num}{miner}{nonce}".encode()
    hash_val = int(hashlib.sha256(data).hexdigest(), 16)
    threshold = 2**(256 - DIFFICULTY)
    return hash_val < threshold, hash_val

def get_block_info():
    """Get current block info via HTTP"""
    import urllib.request
    import json
    
    data = {
        "jsonrpc": "2.0",
        "method": "eth_getBlockByNumber",
        "params": ["latest", False],
        "id": 1
    }
    
    req = urllib.request.Request(
        RPC_URL,
        data=json.dumps(data).encode(),
        headers={"Content-Type": "application/json"}
    )
    
    with urllib.request.urlopen(req) as response:
        result = json.loads(response.read())
        block = result.get("result", {})
        return int(block["number"], 16), int(block["timestamp"], 16)

def mine():
    print(f"Mining MindMine - Nonce Finder")
    print(f"Contract: {CONTRACT}")
    print(f"Miner: {MINER_ADDRESS}")
    print(f"Difficulty: {DIFFICULTY}")
    print("-" * 50)
    print("Finding valid nonces...")
    print()
    
    nonce = 0
    attempts = 0
    last_block = 0
    
    while True:
        attempts += 1
        
        # Get fresh block info
        try:
            block_num, timestamp = get_block_info()
            if block_num != last_block:
                last_block = block_num
                print(f"Block: {block_num}, Timestamp: {timestamp}")
        except:
            timestamp = int(time.time())
            block_num = 0
        
        # Check proof
        valid, hash_val = check_proof(nonce, timestamp, block_num, MINER_ADDRESS)
        
        if valid:
            print(f"\n{'='*50}")
            print(f"VALID NONCE FOUND!")
            print(f"Nonce: {nonce}")
            print(f"Block: {block_num}")
            print(f"Timestamp: {timestamp}")
            print(f"Hash: {hex(hash_val)}")
            print(f"{'='*50}")
            print("\nTo claim this block, run submit_nonce.py on a machine with web3.py")
            print(f"Nonce value: {nonce}")
            break
        
        nonce += 1
        
        if attempts % 500000 == 0:
            print(f"Attempts: {attempts:,} ...", flush=True)

if __name__ == "__main__":
    mine()
